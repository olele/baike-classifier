package org.neuroph.core.events;

import org.neuroph.core.NeuralNetwork;

/**
 *
 * @author zoran
 */
public class NNCalculatedEvent extends NeuralNetworkEvent {

    public NNCalculatedEvent(NeuralNetwork source) {
        super(source);
    }
    
    
    
}
