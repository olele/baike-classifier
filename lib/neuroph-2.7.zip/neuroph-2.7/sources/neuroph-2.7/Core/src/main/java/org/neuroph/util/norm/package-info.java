/**
 * Provides data normalization techniques
 */
package org.neuroph.util.norm;
