/**
 * Various samples contributed by the community
 */
package org.neuroph.contrib.samples;
